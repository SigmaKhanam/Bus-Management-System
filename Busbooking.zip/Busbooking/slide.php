<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="cssfile/slide.css">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Roboto+Slab:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/flickity/2.2.1/flickity.css">
</head>
<body>

<div class="hero-slider" data-carousel>
	<div class="carousel-cell" style="background-image: url(image/40.jpg);">
		<div class="overlay"></div>
		<div class="inner">
			<h3 class="subtitle"></h3>
			<h2 class="title">We help you to make your journey better</h2>
			<a href="home.php" class="btn">Go to Home</a>
		</div>
	</div>

	<div class="carousel-cell" style="background-image: url(image/45.webp);">
		<div class="overlay"></div>
		<div class="inner">
			<h3 class="subtitle"></h3>
			<h2 class="title">We give you maximum choice across all the routes to choose your bus</h2>
			<a href="home.php" class="btn">Go to Home</a>
		</div>
	</div>

	<div class="carousel-cell" style="background-image: url(image/48.jpg);">
		<div class="overlay"></div>
		<div class="inner">
			<h3 class="subtitle"></h3>
			<h2 class="title">Customer service is available 24/7</h2>
			<a href="home.php" class="btn">Go to Home</a>
		</div>
	</div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/flickity/2.2.1/flickity.pkgd.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>






</body>
</html>
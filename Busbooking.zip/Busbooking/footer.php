<footer>
        <div class="footerInfo">
            <div class="footerContainer">
                <div class="footerItem">

                    <div class="socialInfo">
                        <div class="mainTitle">
                            <h4> Follow Us <span></span></h4>
                        </div>
                        <div class="socialItem">
                            <div class="socialLink facebook">
                                <i class="fab fa-facebook-f"></i>
                            </div>
                            <div class="socialLink instagram">
                                <i class="fab fa-instagram"></i>
                            </div>
                            <div class="socialLink twitter">
                                <i class="fab fa-twitter"></i>
                            </div>
                        </div>
                    </div>
<!--  -->
                    <div class="socialInfo">
                        <div class="mainTitle">
                            <h4> Service <span></span></h4>
                        </div>
                        <div class="socialItem">
                            <a href="#"> Emergency medical care </a>
                            <a href="#"> check up</a>
                            <a href="#"> treatment of personal diseases </a>
                            <a href="#"></a>
                        </div>
                    </div>
<!--  -->
                    <div class="socialInfo">
                        <div class="mainTitle">
                            <h4>Get Help<span></span></h4>
                        </div>
                        <div class="socialItem">
                            <a href="#">We help you</a>
                            <a href="#">to make</a>
                            <a href="#">your journey better</a>
                            <a href="#"> </a>
                        </div>
                    </div>
<!--  -->
                    <div class="socialInfo">
                        <div class="mainTitle">
                            <h4>Contact<span></span></h4>
                        </div>
                        <h5 class="addressTitle">Chattogram,Bangladesh</h5>
                        <div class="callInfo">
                            <h6>Call</h6> <i class="fas fa-arrow-right"></i>
                            <span>+8801824118677</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </footer>


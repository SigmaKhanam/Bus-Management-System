var albox = document.getElementById("alert-additional-content-5");
var close = document.getElementById("close");

function Close(){
    albox.style.opacity = 0;
    albox.style.transition = "all 3s";
}